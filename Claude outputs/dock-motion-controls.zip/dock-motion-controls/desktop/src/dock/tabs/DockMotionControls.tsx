/**
 * DockMotionControls.tsx — Dock controls for Motion lower thirds (public/kinetic).
 *
 * Motion straps are bare animated text, so there is no background or box styling.
 * The operator gets: IN / OUT / AUTO, the text fields, hold time, speed, size,
 * position, text colour and "loop auto".
 *
 *   IN   — animate in and stay on air until OUT.
 *   OUT  — animate out.
 *   AUTO — animate in, hold for "Hold (seconds)", animate out. With "Loop auto"
 *          the overlay repeats that cycle until another command is sent.
 *
 * Keyboard: I = in, O = out, A = auto (ignored while typing in a field).
 */

import { useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import type { LowerThirdTheme, LTPosition } from "../../lowerthirds/types";
import { LT_POSITION_LABELS, LT_POSITIONS } from "../../lowerthirds/types";

export interface DockMotionSpeaker {
  name: string;
  role: string;
  isMain?: boolean;
}

interface DockMotionControlsProps {
  theme: LowerThirdTheme;
  values: Record<string, string>;
  onValueChange: (key: string, value: string) => void;
  position: LTPosition;
  onPositionChange: (position: LTPosition) => void;
  speakers: DockMotionSpeaker[];
  selectedSpeakerIdx: number | null;
  onSelectSpeaker: (index: number | null) => void;
  onIn: () => void;
  onOut: () => void;
  onAuto: () => void;
  sending: boolean;
}

const SPEED_OPTIONS = ["0.5", "0.75", "1", "1.25", "1.5", "2"];

function hexOr(value: string | undefined, fallback: string): string {
  const v = (value || "").trim();
  if (/^#[0-9a-f]{6}$/i.test(v)) return v.toLowerCase();
  if (/^#[0-9a-f]{3}$/i.test(v)) return `#${v.slice(1).split("").map((c) => c + c).join("")}`.toLowerCase();
  return fallback;
}

const labelStyle: React.CSSProperties = {
  display: "block",
  fontSize: 10,
  color: "var(--dock-text-dim)",
  marginBottom: 4,
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  boxSizing: "border-box",
  background: "var(--dock-input-bg, var(--dock-surface))",
  border: "1px solid var(--dock-border)",
  borderRadius: 3,
  padding: "6px 8px",
  fontSize: 12,
  fontWeight: 600,
  color: "var(--dock-text)",
  fontFamily: "inherit",
};

function TakeButton({ label, hotkey, onClick, primary, disabled, title }: {
  label: string; hotkey: string; onClick: () => void; primary?: boolean; disabled?: boolean; title: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={title}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 8,
        padding: "7px 12px",
        borderRadius: 3,
        border: `1px solid ${primary ? "#e8503a" : "var(--dock-border)"}`,
        background: primary ? "#e8503a" : "var(--dock-input-bg, var(--dock-surface))",
        color: primary ? "#ffffff" : "var(--dock-text)",
        fontFamily: "inherit",
        fontSize: 12,
        fontWeight: 800,
        letterSpacing: 0.4,
        cursor: disabled ? "default" : "pointer",
        opacity: disabled ? 0.6 : 1,
      }}
    >
      {label}
      <kbd style={{
        fontSize: 9,
        fontWeight: 600,
        fontFamily: "inherit",
        padding: "0 4px",
        border: `1px solid ${primary ? "rgba(255,255,255,.7)" : "var(--dock-border)"}`,
        borderRadius: 2,
        lineHeight: "13px",
      }}>{hotkey}</kbd>
    </button>
  );
}

export default function DockMotionControls({
  theme,
  values,
  onValueChange,
  position,
  onPositionChange,
  speakers,
  selectedSpeakerIdx,
  onSelectSpeaker,
  onIn,
  onOut,
  onAuto,
  sending,
}: DockMotionControlsProps) {
  const { t } = useTranslation();
  const actionsRef = useRef({ onIn, onOut, onAuto, sending });
  actionsRef.current = { onIn, onOut, onAuto, sending };

  // Hotkeys: I / O / A while the Dock has focus and the user is not typing.
  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.metaKey || event.ctrlKey || event.altKey) return;
      const target = event.target as HTMLElement | null;
      if (target && (target.isContentEditable || /^(input|textarea|select)$/i.test(target.tagName))) return;
      const key = event.key.toLowerCase();
      const actions = actionsRef.current;
      if (actions.sending) return;
      if (key === "i") { event.preventDefault(); actions.onIn(); }
      else if (key === "o") { event.preventDefault(); actions.onOut(); }
      else if (key === "a") { event.preventDefault(); actions.onAuto(); }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const textFields = theme.variables.filter((v) => v.type === "text" && !v.key.startsWith("kx"));
  const defaultOf = (key: string, fallback: string) => theme.variables.find((v) => v.key === key)?.defaultValue ?? fallback;
  const value = (key: string, fallback: string) => {
    const v = values[key];
    return v !== undefined && v !== "" ? v : defaultOf(key, fallback);
  };
  const scale = Number(value("kxScale", "1")) || 1;
  const speed = value("kxSpeed", "1");
  const speedOptions = SPEED_OPTIONS.includes(speed) ? SPEED_OPTIONS : [...SPEED_OPTIONS, speed].sort((a, b) => Number(a) - Number(b));
  const loopOn = value("kxLoop", "0") === "1";
  const title = theme.name.replace(/:\s*/, " · ").toUpperCase();

  return (
    <section
      aria-label={t("lowerThird.motionControls", "Motion lower third")}
      style={{
        border: "1px solid var(--dock-border)",
        borderRadius: 4,
        background: "var(--dock-surface)",
        padding: 10,
        display: "grid",
        gap: 10,
      }}
    >
      <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.6, color: "var(--dock-text-dim)" }}>
        {title}
      </div>

      <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
        <TakeButton label={t("lowerThird.take.in", "IN")} hotkey="I" primary onClick={onIn} disabled={sending}
          title={t("lowerThird.take.inHint", "Animate in and stay on until OUT")} />
        <TakeButton label={t("lowerThird.take.out", "OUT")} hotkey="O" onClick={onOut} disabled={sending}
          title={t("lowerThird.take.outHint", "Animate out")} />
        <TakeButton label={t("lowerThird.take.auto", "AUTO")} hotkey="A" onClick={onAuto} disabled={sending}
          title={t("lowerThird.take.autoHint", "Animate in, hold, then animate out")} />
      </div>

      {speakers.length > 0 && (
        <div>
          <label style={labelStyle} htmlFor="dock-motion-speaker">{t("lowerThird.speaker", "Speaker")}</label>
          <select
            id="dock-motion-speaker"
            value={selectedSpeakerIdx ?? ""}
            onChange={(e) => {
              const idx = Number(e.target.value);
              onSelectSpeaker(e.target.value === "" || Number.isNaN(idx) ? null : idx);
            }}
            style={inputStyle}
          >
            <option value="">—</option>
            {speakers.map((sp, i) => (
              <option key={`${sp.name}-${i}`} value={i}>
                {sp.name}{sp.isMain ? " ★" : ""}{sp.role ? ` — ${sp.role}` : ""}
              </option>
            ))}
          </select>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 }}>
        {textFields.map((v) => (
          <div key={v.key} style={{ minWidth: 0 }}>
            <label style={labelStyle} htmlFor={`dock-motion-${v.key}`}>{v.label || v.key}</label>
            <input
              id={`dock-motion-${v.key}`}
              type="text"
              value={values[v.key] ?? ""}
              placeholder={v.placeholder || v.defaultValue || ""}
              onChange={(e) => onValueChange(v.key, e.target.value)}
              style={inputStyle}
            />
          </div>
        ))}
      </div>

      <hr style={{ border: 0, borderTop: "1px solid var(--dock-border)", margin: 0 }} />

      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10, alignItems: "end" }}>
        <div>
          <label style={labelStyle} htmlFor="dock-motion-hold">{t("lowerThird.holdSeconds", "Hold (seconds)")}</label>
          <input
            id="dock-motion-hold"
            type="number"
            min={1}
            max={600}
            step={1}
            value={value("kxAutoOut", "5")}
            onChange={(e) => onValueChange("kxAutoOut", e.target.value)}
            style={inputStyle}
          />
        </div>
        <div>
          <label style={labelStyle} htmlFor="dock-motion-speed">{t("lowerThird.motionSpeed", "Speed")}</label>
          <select id="dock-motion-speed" value={speed} onChange={(e) => onValueChange("kxSpeed", e.target.value)} style={inputStyle}>
            {speedOptions.map((s) => <option key={s} value={s}>{s}×</option>)}
          </select>
        </div>
        <div>
          <label style={labelStyle} htmlFor="dock-motion-size">
            {t("lowerThird.motionSize", "Size")} <span style={{ color: "var(--dock-text)" }}>{Math.round(scale * 100)}%</span>
          </label>
          <input
            id="dock-motion-size"
            type="range"
            min={0.6}
            max={1.6}
            step={0.05}
            value={scale}
            onChange={(e) => onValueChange("kxScale", e.target.value)}
            style={{ width: "100%", accentColor: "var(--dock-accent, #4ade80)" }}
          />
        </div>
        <div>
          <label style={labelStyle} htmlFor="dock-motion-position">{t("lowerThird.position", "Position")}</label>
          <select
            id="dock-motion-position"
            value={position}
            onChange={(e) => onPositionChange(e.target.value as LTPosition)}
            style={inputStyle}
          >
            {LT_POSITIONS.map((p) => (
              <option key={p} value={p}>{t(`lowerThird.positions.${p}`, LT_POSITION_LABELS[p])}</option>
            ))}
          </select>
        </div>
        <div>
          <label style={labelStyle} htmlFor="dock-motion-color">{t("lowerThird.textColor", "Text colour")}</label>
          <input
            id="dock-motion-color"
            type="color"
            value={hexOr(value("kxColor", "#ffffff"), "#ffffff")}
            onChange={(e) => onValueChange("kxColor", e.target.value)}
            style={{ ...inputStyle, height: 30, padding: 2, cursor: "pointer" }}
          />
        </div>
        <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 11, color: "var(--dock-text)", paddingBottom: 6, cursor: "pointer" }}>
          <input
            type="checkbox"
            checked={loopOn}
            onChange={(e) => onValueChange("kxLoop", e.target.checked ? "1" : "0")}
          />
          {t("lowerThird.loopAuto", "Loop auto")}
        </label>
      </div>
    </section>
  );
}
